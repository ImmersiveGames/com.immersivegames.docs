(function () {
  const input = document.querySelector("#docs-search-input");
  const status = document.querySelector("#docs-search-status");
  const globalToggle = document.querySelector("[data-action='toggle-search-mode']");
  const globalResults = document.querySelector("[data-global-results]");
  const emptyState = document.querySelector("[data-empty-state]");
  let globalMode = false;

  if (!input) return;

  function normalize(value) {
    return (value || "").trim().toLowerCase();
  }

  function getSnippet(text, query) {
    const clean = text.replace(/\s+/g, " ").trim();
    const index = clean.toLowerCase().indexOf(query);
    if (index < 0) return clean.slice(0, 140);
    return clean.slice(Math.max(0, index - 50), Math.min(clean.length, index + query.length + 90));
  }

  function clearFiltering() {
    document.querySelectorAll(".is-search-hidden").forEach((node) => node.classList.remove("is-search-hidden"));
    if (emptyState) emptyState.hidden = true;
    if (globalResults) {
      globalResults.hidden = true;
      globalResults.innerHTML = "";
    }
  }

  function activeDocumentSearch(query) {
    const active = window.docsNavigation ? window.docsNavigation.getActiveDocument() : document.querySelector(".docs-document.is-active");
    if (!active) return 0;

    const sections = Array.from(active.querySelectorAll(".docs-section"));
    let count = 0;

    sections.forEach((section) => {
      const match = section.textContent.toLowerCase().includes(query);
      section.classList.toggle("is-search-hidden", !match);
      if (match) count += 1;
    });

    document.querySelectorAll("[data-nav-target], [data-toc-target]").forEach((link) => {
      const target = active.querySelector(`#${CSS.escape(link.dataset.navTarget || link.dataset.tocTarget || "")}`);
      if (target && target.classList.contains("docs-section")) {
        link.classList.toggle("is-search-hidden", target.classList.contains("is-search-hidden"));
      }
    });

    if (emptyState) emptyState.hidden = count !== 0;
    return count;
  }

  function globalSearch(query) {
    const results = [];
    document.querySelectorAll("[data-document]").forEach((doc) => {
      const docTitle = doc.dataset.documentTitle || "Document";
      doc.querySelectorAll("h2[id], .docs-section[id]").forEach((section) => {
        const text = section.textContent || "";
        if (text.toLowerCase().includes(query)) {
          const heading = section.matches("h2") ? section : section.querySelector("h3, h2, h4");
          results.push({
            documentId: doc.dataset.document,
            documentTitle: docTitle,
            title: section.dataset.title || (heading ? heading.textContent.trim() : section.id),
            id: section.id,
            snippet: getSnippet(text, query)
          });
        }
      });
    });

    if (globalResults) {
      globalResults.innerHTML = results.map((result) => `
        <div class="docs-search-result">
          <a href="#${result.id}" data-search-result data-document-id="${result.documentId}">${result.title}</a>
          <small>${result.documentTitle}</small>
          <p>${result.snippet}</p>
        </div>
      `).join("");
      globalResults.hidden = results.length === 0;
    }

    if (emptyState) emptyState.hidden = results.length !== 0;
    return results.length;
  }

  function runSearch() {
    const query = normalize(input.value);
    clearFiltering();

    if (!query) {
      status.textContent = "Search is ready.";
      return;
    }

    const count = globalMode ? globalSearch(query) : activeDocumentSearch(query);
    status.textContent = count === 0
      ? "No results found."
      : globalMode
        ? `${count} results across documents.`
        : `${count} sections found.`;
  }

  input.addEventListener("input", runSearch);
  input.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      input.value = "";
      runSearch();
      input.blur();
    }
  });

  if (globalToggle) {
    globalToggle.addEventListener("click", () => {
      globalMode = !globalMode;
      globalToggle.setAttribute("aria-pressed", String(globalMode));
      globalToggle.textContent = globalMode ? "Active" : "Global";
      runSearch();
    });
  }

  document.addEventListener("click", (event) => {
    const result = event.target.closest("[data-search-result]");
    if (result && window.docsNavigation) {
      window.docsNavigation.setActiveDocument(result.dataset.documentId, { preserveScroll: true });
    }
  });

  document.addEventListener("docs:document-changed", () => {
    input.value = "";
    clearFiltering();
    status.textContent = "Search reset for active document.";
  });
})();
